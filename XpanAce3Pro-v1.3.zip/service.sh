#!/system/bin/sh
# 兜底：如果 hook APK 因为系统升级等原因丢了，开机补装一次
MODDIR=${0%/*}
APK="$MODDIR/payload/XpanHook.apk"
DEX="$MODDIR/payload/enabler.dex"
[ -f "$APK" ] || exit 0

if ! pm list packages 2>/dev/null | grep -q com.xpanport.hook; then
    pm install -r -d "$APK" >/dev/null 2>&1
    [ -f "$DEX" ] && CLASSPATH="$DEX" app_process /system/bin com.xpanport.setup.Enabler >/dev/null 2>&1
fi

# 2× 真变焦已改为 hook 内即时切换（拍照流小流 + CropInfo 改值），
# 不再需要后台脚本换配置/重启相机 —— 旧的 crop_watch.sh 机制已移除（2026-10-25）。
