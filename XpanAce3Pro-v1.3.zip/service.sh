#!/system/bin/sh
# 兜底：如果 hook APK 因为系统升级等原因丢了，开机补装一次
MODDIR=${0%/*}
APK="$MODDIR/payload/XpanHook.apk"
DEX="$MODDIR/payload/enabler.dex"
[ -f "$APK" ] || exit 0

if ! pm list packages 2>/dev/null | grep -q com.xpanport.hook; then
    pm install -r -d "$APK" >/dev/null 2>&1
    [ -f "$DEX" ] && CLASSPATH="$DEX" app_process /system/bin com.xpanport.setup.Enabler >/dev/null 2>&1
fi

# 2× 真变焦：后台监听 hook 写的请求文件，换裁剪窗口配置并重建会话
if [ -f "$MODDIR/crop_watch.sh" ]; then
    (nohup sh "$MODDIR/crop_watch.sh" >/dev/null 2>&1 &)
fi
