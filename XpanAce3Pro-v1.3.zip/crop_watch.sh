#!/system/bin/sh
# X-Pan 2× 真变焦：配置换带 + 重启相机进程（root 侧）
# hook（XpanHook.java）识别用户点的档位，写请求文件 /sdcard/Android/data/com.oplus.camera/files/xpan_cropzoom
# 本脚本轮询请求文件，变化时：bind-mount 对应配置 → 重启相机进程 → 清 busy 标记。
# 支持档位：1（1× 原窗口）/ 2（2× 居中带，实测 FOV 0.55）
#
# ★★ 为什么是"重启相机进程"而不是"模式往返重建会话"：
#   应用只在进程启动时解析一次 oplus_camera_config（含 2× 裁剪窗口 tag），之后全走内存缓存。
#   2026-10-24 深夜实测：模式往返（XPAN→哈苏超清→XPAN，模式确实切过去了）之后出片 FOV 仍是 1×
#   —— 会话重建了，裁剪窗口还是旧的。唯一可靠的重建 = 进程重启。
#   相机重启后会自动恢复上次的模式（实测直接回到 X-Pan，皮肤完整，走应用自己的直开路径），
#   不点任何屏幕坐标 —— 旧的"注入点按"整类风险（点偏/点到别的应用/横竖屏坐标错）全部消失。
MODDIR=${0%/*}
CFG=/odm/etc/camera/config/oplus_camera_config
REQ=/sdcard/Android/data/com.oplus.camera/files/xpan_cropzoom
BUSY=/sdcard/Android/data/com.oplus.camera/files/xpan_cropzoom_busy
cur=""

# busy 残留清理（上次中途死掉会留这个，不清掉 hook 会认为一直在切换）
rm -f "$BUSY" 2>/dev/null
# 退出时也摘掉 busy，别把卡死状态留给下一次
trap 'rm -f "$BUSY" 2>/dev/null; exit' INT TERM EXIT

# 单实例保护：清掉旧实例（双实例会双重动作）
for p2 in $(ps -ef | grep crop_watch | grep -v grep | awk '{print $2}'); do
    [ "$p2" != "$$" ] && kill "$p2" 2>/dev/null
done

while true; do
    # timeout 包住 cat：系统内存重压时 FUSE 层会挂起，cat 可能永远不返回
    # （实测一次：watcher 卡在 cat 上再也不动）。没有 timeout 命令就退回裸读。
    if command -v timeout >/dev/null 2>&1; then
        v=$(timeout 2 cat "$REQ" 2>/dev/null | tr -d ' \r\n')
    else
        v=$(cat "$REQ" 2>/dev/null | tr -d ' \r\n')
    fi
    case "$v" in
        1|2|15|18|22) ;;
        *) sleep 1; continue ;;
    esac
    if [ "$v" != "$cur" ]; then
        f="$MODDIR/payload/oc_$v.enc"
        if [ -f "$f" ]; then
            touch "$BUSY"
            # 换配置：先摘掉自己上一层动态 bind（避免层层叠加；没有层时 umount 报错，忽略），
            # 然后只在内容真不同的时候挂（模块静态 overlay 本来就是 oc_1 的话就不必再挂一层）。
            umount "$CFG" 2>/dev/null
            sleep 0.3
            tgt=$(md5sum "$f" 2>/dev/null | cut -d' ' -f1)
            now=$(md5sum "$CFG" 2>/dev/null | cut -d' ' -f1)
            if [ -n "$tgt" ] && [ "$tgt" != "$now" ]; then
                cp -f "$f" /data/local/tmp/oc_active.enc
                chmod 644 /data/local/tmp/oc_active.enc
                chcon u:object_r:vendor_configs_file:s0 /data/local/tmp/oc_active.enc 2>/dev/null
                mount --bind /data/local/tmp/oc_active.enc "$CFG"
            fi
            # ★ 前台守卫：相机不在前台绝不重启它（重启会把相机拽到用户正在用的应用上面
            #   —— 和以前"盲点坐标点进 QQ"是同类事故）。最多等 30 秒。
            fg=""
            for w in 1 2 3 4 5 6; do
                fg=$(dumpsys window 2>/dev/null | grep -m1 mCurrentFocus)
                case "$fg" in *com.oplus.camera*) break ;; esac
                sleep 5
            done
            case "$fg" in
                *com.oplus.camera*) ;;
                *) rm -f "$BUSY"; log -t XpanCrop "相机不在前台，只挂配置不重启（下次打开相机生效）"; cur="$v"; continue ;;
            esac
            # ★ 负载守卫：系统高负载/内存紧张时不重启相机 —— 进程冷启动是大突发，重压下
            #   会把系统挤到 ANR（实测 21:09 整机假死：load 63、内存只剩 300M）。最多等 30 秒，
            #   超时就只挂配置不重启（用户下次手动打开相机时自然生效）。
            loadok=""
            for w in 1 2 3 4 5 6; do
                l1=$(cut -d' ' -f1 /proc/loadavg 2>/dev/null)
                ma=$(grep -m1 MemAvailable /proc/meminfo 2>/dev/null | tr -dc '0-9')
                [ -z "$l1" ] && l1=0
                [ -z "$ma" ] && ma=999999999
                if [ "${l1%%.*}" -le 15 ] && [ "$ma" -ge 1200000 ]; then loadok=1; break; fi
                sleep 5
            done
            if [ -z "$loadok" ]; then
                rm -f "$BUSY"
                log -t XpanCrop "系统负载过高(load=$l1 MemAvail=${ma}kB)，只挂配置不重启，下次打开相机生效"
                cur="$v"; continue
            fi
            # 会话重建：重启相机进程（见文件头注释）。重启后应用自己恢复到 X-Pan。
            am force-stop com.oplus.camera
            sleep 1
            monkey -p com.oplus.camera -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1
            # 等它起完（最多 15 秒），busy 这期间保持置位（hook 侧 30 秒超时兜底）
            w2=0
            while [ $w2 -lt 15 ]; do
                fg=$(dumpsys window 2>/dev/null | grep -m1 mCurrentFocus)
                case "$fg" in *com.oplus.camera*) break ;; esac
                sleep 1
                w2=$((w2+1))
            done
            rm -f "$BUSY"
            log -t XpanCrop "配置已切到 ${v}× 并重启相机重建会话"
        else
            log -t XpanCrop "缺少配置 $f"
        fi
        cur="$v"
    fi
    sleep 1
done
