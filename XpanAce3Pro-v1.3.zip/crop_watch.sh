#!/system/bin/sh
# X-Pan 2× 真变焦：配置换带 + 会话重建（root 侧）
# hook（XpanHook.java）识别用户点的档位，写请求文件 /sdcard/Android/data/com.oplus.camera/files/xpan_cropzoom
# 本脚本轮询请求文件，变化时：bind-mount 对应配置 → 走一趟模式往返让会话重建 → 清 busy 标记。
# 支持档位：1（1× 原窗口）/ 2（2× 居中带，实测 FOV 0.55）
MODDIR=${0%/*}
CFG=/odm/etc/camera/config/oplus_camera_config
REQ=/sdcard/Android/data/com.oplus.camera/files/xpan_cropzoom
BUSY=/sdcard/Android/data/com.oplus.camera/files/xpan_cropzoom_busy
cur=""

# busy 残留清理（上次中途死掉会留这个，不清掉 hook 会认为一直在切换）
rm -f "$BUSY" 2>/dev/null
# 退出时也摘掉 busy，别把卡死状态留给下一次
trap 'rm -f "$BUSY" 2>/dev/null; exit' INT TERM EXIT

# 单实例保护：清掉旧实例（双实例会双重往返，模式跳两次）
for p2 in $(ps -ef | grep crop_watch | grep -v grep | awk '{print $2}'); do
    [ "$p2" != "$$" ] && kill "$p2" 2>/dev/null
done

while true; do
    # timeout 包住 cat：系统内存重压时 FUSE 层会挂起，cat 可能永远不返回
    # （实测一次：watcher 卡在 cat 上再也不动）。没有 timeout 命令就退回裸读。
    if command -v timeout >/dev/null 2>&1; then
        v=$(timeout 2 cat "$REQ" 2>/dev/null | tr -d ' \r\n')
    else
        v=$(cat "$REQ" 2>/dev/null | tr -d ' \r\n')
    fi
    case "$v" in
        1|2|15|18|22) ;;
        *) sleep 1; continue ;;
    esac
    if [ "$v" != "$cur" ]; then
        f="$MODDIR/payload/oc_$v.enc"
        if [ -f "$f" ]; then
            touch "$BUSY"
            cp -f "$f" /data/local/tmp/oc_active.enc
            chmod 644 /data/local/tmp/oc_active.enc
            chcon u:object_r:vendor_configs_file:s0 /data/local/tmp/oc_active.enc 2>/dev/null
            mount --bind /data/local/tmp/oc_active.enc "$CFG"
            # 会话重建：模式往返一趟（X-Pan → 照片 → X-Pan），按屏幕方向选导航方式。
            # 竖屏：模式条在底部横排，直接点标签（实测可靠，划动会被吸附弹回）；
            # 横屏：模式列表在右侧竖排，慢速滑动往返（实测可靠）。
            # ★ 前台守卫：相机不在前台绝不点屏幕（用户切去 QQ/浏览器时，
            #   盲点坐标会点进别的应用 —— 实测差点往 QQ 里点消息）。最多等 30 秒。
            fg=""
            for w in 1 2 3 4 5 6; do
                fg=$(dumpsys window 2>/dev/null | grep -m1 mCurrentFocus)
                case "$fg" in *com.oplus.camera*) break ;; esac
                sleep 5
            done
            case "$fg" in
                *com.oplus.camera*) ;;
                *) rm -f "$BUSY"; log -t XpanCrop "相机不在前台，放弃本次往返（配置已挂上，重进 X-Pan 生效）"; cur="$v"; continue ;;
            esac
            # ★ 负载守卫：系统高负载/内存紧张时绝不注入往返 —— 相机重建会话
            #   是大突发，重压下会把相机主线程挤到 ANR（实测 21:09 整机假死：
            #   load 63、内存只剩 300M、抖音+王者同时吃满 8 核）。最多等 30 秒，
            #   超时就只挂配置不点屏幕（下次手动进出 X-Pan 时新会话自然生效）。
            loadok=""
            for w in 1 2 3 4 5 6; do
                l1=$(cut -d' ' -f1 /proc/loadavg 2>/dev/null)
                ma=$(grep -m1 MemAvailable /proc/meminfo 2>/dev/null | tr -dc '0-9')
                [ -z "$l1" ] && l1=0
                [ -z "$ma" ] && ma=999999999
                if [ "${l1%%.*}" -le 15 ] && [ "$ma" -ge 1200000 ]; then loadok=1; break; fi
                sleep 5
            done
            if [ -z "$loadok" ]; then
                rm -f "$BUSY"
                log -t XpanCrop "系统负载过高(load=$l1 MemAvail=${ma}kB)，只挂配置不重建会话，下次进出 X-Pan 生效"
                cur="$v"; continue
            fi
            ORIENT=$(dumpsys input 2>/dev/null | grep -m1 SurfaceOrientation | tr -d '\r' | awk '{print $2}')
            case "$ORIENT" in
                1|3)
                    input swipe 2150 900 2150 700 600; sleep 1
                    input swipe 2150 900 2150 700 600; sleep 2
                    input swipe 2150 700 2150 900 600; sleep 1
                    input swipe 2150 700 2150 900 600; sleep 2
                    ;;
                *)
                    input tap 90 2070; sleep 2
                    input tap 1150 2100; sleep 2
                    ;;
            esac
            rm -f "$BUSY"
            log -t XpanCrop "裁剪窗口已切到 ${v}× 并重建会话"
        else
            log -t XpanCrop "缺少配置 $f"
        fi
        cur="$v"
    fi
    sleep 1
done
